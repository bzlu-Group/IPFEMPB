Move  all files in folder ADP(1V4Z, 1A36, 3LOD, 1RMP, 1BL8, AChE) to ../Code and run:

make
mpirun -np 10 ./IPFEMPB -options_file XXX.options