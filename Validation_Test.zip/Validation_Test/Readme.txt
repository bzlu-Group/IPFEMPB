Move file test_LPBE.options(test_NPBE.options) to folder ../Code and run:

make
mpirun -np 4 ./demo -options_file test_LPBE.options